#two methods needed
#one for finding unverified file info the other for building a JSON with the file's contents

import os
import json


def getInfo():
    with open('/Users/ankit/Documents/Misinformation/dataMaker-master/annotations-dheeraj.json') as fp:
        data = json.load(fp)
    return data

data = getInfo()['annotation']
names = []


for each_data_point in data:
    if each_data_point['class'] =='1':
        names.append(each_data_point['name']+'.txt')

def makeJSON(list_of_files, path_to_all_files):
    json_list = []
    list_of_all_files = os.listdir((path_to_all_files))
    print(list_of_all_files)
    for a_file in list_of_all_files:
        if a_file in list_of_files:
           print(a_file)
           with open(a_file, encoding='cp1252') as current_file_pointer:
            data = current_file_pointer.read()
            print(data)
            temp = {'ID' : a_file,
                    'Text' : data}

            json_list.append(temp)

    json_object = json.dumps(json_list, indent=4)
    with open('unverfiedNEWS.json', 'w') as output_file_pointer:
        output_file_pointer.write(json_object)

makeJSON(names, '/Users/ankit/Documents/Misinformation/data files')
